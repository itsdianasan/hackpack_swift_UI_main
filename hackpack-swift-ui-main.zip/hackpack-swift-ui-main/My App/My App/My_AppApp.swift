//
//  My_AppApp.swift
//  My App
//
//  Created by Irfan Nafi on 10/15/23.
//

import SwiftUI

@main
struct My_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
